package it.prova.model;

public enum StatoLavorazione {
	
	IN_INSERIMENTO, 
	IN_LAVORAZIONE, 
	IN_ASSEMBLAGGIO, 
	IN_VERNICIATURA, 
	IN_MESSA_IN_OPERA,
	PRONTA;

}
