package it.prova.service;

import it.prova.model.MateriaPrima;

public interface LavorazioneService {

	public void eseguiLavorazione(MateriaPrima materiaPrima);
	
}
