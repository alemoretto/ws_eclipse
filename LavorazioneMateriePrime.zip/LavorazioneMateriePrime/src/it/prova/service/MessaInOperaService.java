package it.prova.service;

import it.prova.model.MateriaPrima;

public interface MessaInOperaService {

	public void eseguiMessaInOpera(MateriaPrima materiaPrima);
	
}
