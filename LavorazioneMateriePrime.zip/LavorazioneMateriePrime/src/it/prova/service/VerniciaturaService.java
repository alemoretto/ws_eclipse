package it.prova.service;

import it.prova.model.MateriaPrima;

public interface VerniciaturaService {

	public void eseguiVerniciatura(MateriaPrima materiaPrima);
	
}
