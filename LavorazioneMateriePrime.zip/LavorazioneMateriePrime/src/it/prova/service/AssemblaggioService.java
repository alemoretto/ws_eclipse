package it.prova.service;

import it.prova.model.MateriaPrima;

public interface AssemblaggioService {

	public void eseguiAssemblaggio(MateriaPrima materiaPrima);

}
